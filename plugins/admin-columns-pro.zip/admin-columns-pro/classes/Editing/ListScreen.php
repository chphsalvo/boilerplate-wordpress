<?php

namespace ACP\Editing;

interface ListScreen {

	/**
	 * @return Strategy
	 */
	public function editing();

}