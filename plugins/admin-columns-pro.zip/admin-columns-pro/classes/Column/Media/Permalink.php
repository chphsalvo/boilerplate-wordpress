<?php

namespace ACP\Column\Media;

use ACP\Column\Post;

class Permalink extends Post\Permalink {

}