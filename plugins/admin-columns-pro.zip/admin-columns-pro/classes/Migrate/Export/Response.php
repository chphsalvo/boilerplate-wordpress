<?php

namespace ACP\Migrate\Export;

interface Response {

	/**
	 * @return void
	 */
	public function send();

}